package com.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//import com.dbconnection.DbConnection;
import com.google.gson.Gson;

@WebServlet("/Addservlet")
public class Addservlet extends HttpServlet {
private static final long serialVersionUID = 1L;
       
    
    public Addservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		try {
			HashMap<Object,Object> Response = new HashMap<Object,Object>(); 
			String business_code= request.getParameter ("business_code");
			String cust_number = request.getParameter ("cust_number"); 
			String clear_date= request.getParameter ("clear_date");
			String buisness_year= request.getParameter ("buisness_year"); 
			String doc_id = request.getParameter("doc_id");
			String posting_date= request.getParameter ("posting_date");
			String document_create_date= request.getParameter ("document_create_date");
			String due_in_date = request.getParameter ("due_in_date");
			String invoice_currency = request.getParameter("invoice_currency");
			String document_type= request.getParameter ("document_type"); 
			String posting_id = request.getParameter ("posting_id");
			String total_open_amount = request.getParameter("total_open_amount");
			String baseline_create_date= request.getParameter ("baseline_create_date");
			String cust_payment_terms = request.getParameter ("cust_payment terms");
			String invoice_id = request.getParameter ("invoice_id");
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/grey_goose","root","root");
			
			String query = "INSERT INTO winter_internship(business_code,cust_number,clear_date, buisness_year, doc_id, posting_date, document_create_date, due_in_date, invoice_currency, document_type, posting_id, total_open_amount, baseline_create_date, cust_payment_terms, invoice_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			
			PreparedStatement st = con.prepareStatement(query);
			
			st.setString(1, business_code );
			//st.setInt(2,Integer.parseInt(cust_number));
			st.setString(2,cust_number);
			st.setString(3, clear_date);
			st.setString(4, buisness_year);
			//st.setInt(5,Integer.parseInt(doc_id));
			st.setString(5,doc_id);
			st.setString(6,posting_date);
			st.setString(7,document_create_date);
			st.setString(8,due_in_date);
			st.setString(9,invoice_currency);
			st.setString(10,document_type);
			//st.setInt(11,Integer.parseInt(posting_id));
			st.setString(11,posting_id);
			st.setString(12,total_open_amount);
			st.setString(13,baseline_create_date);
			st.setString(14,cust_payment_terms);
			//st.setInt(15,Integer.parseInt(invoice_id));
			st.setString(15,invoice_id);
			
			if(st.executeUpdate()>0) {
				Response.put("insert", true);
			}else {
				Response.put("insert", false);
			}
			
			Gson gson = new Gson();
			
			String JSONresponse = gson.toJson(Response);
			response.setHeader("Access-Control-Allow-Origin","*");
			response.getWriter().append(JSONresponse);
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
		/**response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		String business_code= request.getParameter ("business_code");
		String cust_number = request.getParameter ("cust_number"); 
		String clear_date= request.getParameter ("clear_date");
		String buisness_year= request.getParameter ("buisness_year"); 
		String doc_id = request.getParameter("doc_id");
		String posting_date= request.getParameter ("posting_date");
		String document_create_date= request.getParameter ("document_create_date");
		String due_in_date = request.getParameter ("due_in_date");
		String invoice_currency = request.getParameter("invoice_currency");
		String document_type= request.getParameter ("document_type"); 
		String posting_id = request.getParameter ("posting_id");
		String total_open_amount = request.getParameter("total_open_amount");
		String baseline_create_date= request.getParameter ("baseline_create_date");
		String cust_payment_terms = request.getParameter ("cust_payment terms");
		String invoice_id = request.getParameter ("invoice_id");
		
		try {
			
			Connection conn = DbConnection.getConnection();
			
			String query = "INSERT INTO grey_goose.winter_internship(business_code,cust_number,clear_date, buisness_year, doc_id, posting_date, document_create_date, due_in_date, invoice_currency, document_type, posting_id, total_open_amount, baseline_create_date, cust_payment_terms, invoice_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		    //String query = "insert into business values (?,?)";
			//String query = "insert into winter_internship values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			
			PreparedStatement st = conn.prepareStatement (query);
		    
			st.setString(1, business_code );
			st.setInt(2,Integer.parseInt(cust_number));
			st.setString(3, clear_date);
			st.setString(4, buisness_year);
			st.setInt(5,Integer.parseInt(doc_id));
			st.setString(6,posting_date);
			st.setString(7,document_create_date);
			st.setString(8,due_in_date);
			st.setString(9,invoice_currency);
			st.setString(10,document_type);
			st.setInt(11,Integer.parseInt(posting_id));
			st.setString(12,total_open_amount);
			st.setString(13,baseline_create_date);
			st.setString(14,cust_payment_terms);
			st.setInt(15,Integer.parseInt(invoice_id));
			
			int i = st.executeUpdate();
			if(i>0) {
				out.print("Successfull");
			}
			conn.close();
		}
		
		catch(Exception e) {
			e.printStackTrace();
		}
	} **/
}
}
