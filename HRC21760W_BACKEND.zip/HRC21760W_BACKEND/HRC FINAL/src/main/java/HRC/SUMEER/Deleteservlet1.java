package com.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

@WebServlet("/Deleteservlet1")
public class Deleteservlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public Deleteservlet1() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		try {
			HashMap<Object,Object> Response = new HashMap<Object,Object>();
			
			String Delete = request.getParameter("sl_no");
			System.out.println(Delete);
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/grey_goose","root","root");
			
			String sql = "DELETE from winter_internship where sl_no in (?)";
			PreparedStatement st = conn.prepareStatement(sql);
			
			st.setString(1, Delete);
			
			if(st.executeUpdate()>0) {
				Response.put("Delete", true);
			}else {
				Response.put("Delete", false);
			}
			
			Gson gson = new Gson();
			response.setHeader("Access-Control-Allow-Origin","*");
			String JSONresponse = gson.toJson(Response);
			response.getWriter().append(JSONresponse);
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
