package com.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.google.gson.Gson;
import com.pojo.Interns;

@WebServlet("/FetchData")
public class Fetch2 extends HttpServlet {
private static final long serialVersionUID = 1L;
 
	 /**
	 * @see HttpServlet#HttpServlet()
	 */
	 public Fetch2() {
	 super();
	 
 }
	 protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException,IOException {
		 HashMap<Object,Object> Response = new HashMap<Object,Object>();
		 ArrayList<Interns> datas = new ArrayList<Interns>();
		 try {
			//load the driver
			Class.forName("com.mysql.cj.jdbc.Driver");
			 //make a connection.
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/grey_goose","root","root");
			//statement
			PreparedStatement st = conn.prepareStatement("SELECT * FROM winter_internship");
			//query execution
			//String query ="SELECT * FROM winter_internship";
			
			ResultSet rs = st.executeQuery();
//Actor - Interns .... Actors - datas.....actor - Intern....actors - intern			
			
			while(rs.next()) {
			Interns Intern = new Interns(rs.getLong("sl_no"),rs.getString("business_code"),rs.getLong("cust_number"),rs.getString("clear_date"),rs.getString("buisness_year"),rs.getString("doc_id"),rs.getString("posting_date"),rs.getString("document_create_date"),rs.getString("document_create_date1"),rs.getString("due_in_date"),rs.getString("invoice_currency"),rs.getString("document_type"),rs.getString("posting_id"),rs.getString("area_business"),rs.getString("total_open_amount"),rs.getString("baseline_create_date"),rs.getString("cust_payment_terms"),rs.getString("invoice_id"),rs.getString("isOpen"),rs.getString("aging_bucket"));
			
			datas.add(Intern);
			}
			Response.put("intern",datas);
		 }catch (Exception e) { 
				e.printStackTrace();
			}
			Gson gson = new Gson();
			String jsonResponse = gson.toJson(Response);
			response.setHeader("Access-Control-Allow-Origin","*");
			response.getWriter().append(jsonResponse);
	}
}